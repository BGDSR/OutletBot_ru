# Telegram Bot (Aiogram 2.25.1)

## Быстрый старт

1. Установи зависимости:
```bash
pip install -r requirements.txt
```

2. Укажи свой токен в `config.py`

3. Запусти бота:
```bash
python bot.py
```