# Вставь сюда свой токен от BotFather
TOKEN = "YOUR_BOT_TOKEN_HERE"